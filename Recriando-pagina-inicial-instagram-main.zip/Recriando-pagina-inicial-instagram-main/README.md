# Recriando a página inicial do Instagram

:triangular_flag_on_post: Para acessar, clique aqui: https://recriandoinstagram.netlify.app/

Desafio proposto e realizado durante o Bootcamp Everis pela Digital Innovation One.

<img src="https://user-images.githubusercontent.com/61888241/97922798-c9bfd380-1d3b-11eb-81ab-48be29a0b015.PNG" width="90%"></img> 
